using UnityEngine;
using UnityEngine.UIElements;

public class hudController : MonoBehaviour
{
    public VisualElement ui;
    public UIDocument UIDocument;

    public Label hpLabel;
    public string hpText;
    public int hpMax = 3;
    public int hp;

    public Label ammoLabel;
    public string ammoText;
    public int ammoMax = 10;
    public int ammo;

    public Label moneyLabel;
    public string moneyText;
    public int money;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Start()
    {
	ui = GetComponent<UIDocument>().rootVisualElement;

	Health();
	Ammo();
	Money();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Health()
    {
	hpLabel = ui.Q<Label>("hp-label");
	hp = 2;

	for(int i = 0; i < hpMax; i++)
	{
	    hpText += (i <= hp-1) ? "♥" : "♡";
	}
	hpLabel.text = hpText;
    }

    void Ammo()
    {
	ammoLabel = ui.Q<Label>("ammo-label");
	ammo = 2;

	ammoText = "⁍ " + ammo.ToString() + " / " + ammoMax.ToString();
	ammoLabel.text = ammoText;
    }

    void Money()
    {
	moneyLabel = ui.Q<Label>("money-label");
	money = 2;

	moneyText = "$ " + money.ToString();
	moneyLabel.text = moneyText;
    }
}
